package com.bignerdranch.android.myapplication_pr15

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var nextButton: Button
    private lateinit var prevButton: Button
    private lateinit var question_TextVeiw: TextView
    private var currentIndex=0

    private val questionBack= listOf(
        Question(R.string.question_1,true),
        Question(R.string.question_2,true),
        Question(R.string.question_3,false),
        Question(R.string.question_4,false),
        Question(R.string.question_5,true)
    )



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        trueButton=findViewById(R.id.true_button)
        falseButton=findViewById(R.id.false_button)
        nextButton=findViewById(R.id.next_button)
        prevButton=findViewById(R.id.prev_button)
        question_TextVeiw=findViewById(R.id.question_text_view)

        trueButton.setOnClickListener { view:View ->
            Toast.LENGTH_SHORT
            checkAnswer(true)
            currentIndex=(currentIndex+1)%questionBack.size
            updateQuestion()
        }
        falseButton.setOnClickListener { view:View ->
            Toast.LENGTH_SHORT
            checkAnswer(false)
            currentIndex=(currentIndex+1)%questionBack.size
            updateQuestion()
        }
        nextButton.setOnClickListener {  view:View ->
            currentIndex=(currentIndex+1)%questionBack.size
            updateQuestion()
        }
        prevButton.setOnClickListener {  view:View ->
            if(currentIndex-1<0){
                currentIndex=questionBack.size-1
            }
            else{
                currentIndex=currentIndex-1
            }
            updateQuestion()
        }

        //val questionTextResid=questionBack[currentIndex].textResId
        //question_TextVeiw.setText(questionTextResid)




        updateQuestion()
    }
    private fun updateQuestion(){
        val questionTextResid=questionBack[currentIndex].textResId
        question_TextVeiw.setText(questionTextResid)
    }
    private fun checkAnswer(userAnswer: Boolean){
        val correctAnswer=questionBack[currentIndex].answer
        val massageResId=if(userAnswer==correctAnswer){
            R.string.correct_toast
        }
        else{
            R.string.incorrect_toast
        }
        Toast.makeText(this,massageResId, Toast.LENGTH_SHORT)
        .show()
    }
}